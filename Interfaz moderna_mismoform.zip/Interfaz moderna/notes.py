from re import X
import tkinter as tk
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage
import tkinter
from numpy import dtype
import serial
from matplotlib import figure
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import Formularios.variables_compartidas
import util.util_ventanas as util_vent
import util.util_imagenes as util_img
from PIL import Image, ImageTk
import os
# from gpiozero import LED,PWMLED

class FormularioIntensidadDesign():
#     #funciones de apagr y prender
    # self.ser = serial.Serial('/dev/ttyACM1',9600) #puerto serie
    def __init__(self, panel_principal):
    # #     #funciones de apagr y prender
        # self.ser = serial.Serial('/dev/ttyACM1',9600) #puerto serie
        try:
            #global ser
            self.ser = serial.Serial('COM13',9600) #puerto serie en pc
        except:
            print("No se pudo conectar el puerto serie")

        # --------------- Esto era necesario solo para los LEDs ----------------
        # self.led = PWMLED(18)
        # self.ledB = PWMLED(6)
        # self.ledC = PWMLED(12)
        # self.ledD = PWMLED(17)
        # self.ledE = PWMLED(19)
        # self.ledF = PWMLED(20)
        # ----------------------------------------------------------------------
        # Cargar la imagen
        # self.canvas = tk.Canvas(panel_principal, width=350, height=160)
        # self.canvas.place(x=50,y=50)

        # ----------------------------------------------------------------------
        # def actualizar_valor(self, event = None):
        #     print("el valor es: ", self.slider1.get())

        # def actualizar_valor_final(self):
        #     event = self.slider1.get()
        #     event = str(event) + '\n'
        #     # ser.write(event.encode())

        # 1. Cargar las imágenes del módulo
        self.image1 = Image.open("./Imagenes/modulo.png")  
        self.image2 = self.image1.resize((280, 180))  # Cambiar el tamaño a 300x200
        self.photo = ImageTk.PhotoImage(self.image2)

        ## Mostrar la imagen en el Canvas
        # self.canvas.create_image(self.image2.width/2, self.image2.height/2, image=self.photo)
        self.modulo = tk.Label(panel_principal, image=self.photo)
        self.modulo.place(relx=0.09,rely=0.1)
        # # self.canvas.create_image(20, 20, anchor=tk.CENTER, image=self.photo)

        ## Crear la imagen transparente como spaceholder para los módulos
        self.imagen_transparente = Image.new('RGBA', (1, 1), (0, 0, 0, 0))
        self.imagen_transparente_tk = ImageTk.PhotoImage(self.imagen_transparente)

        self.mod1 = Image.open("./Imagenes/mod1.png")
        self.mod1_rs = self.mod1.resize((60,53))
        self.mod1_imag = ImageTk.PhotoImage(self.mod1_rs)

        ### Mostrar las imágenes de los módulos en el widget Label
        self.modulo1 = tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo1.place(x=0,y=0)
        
        self.mod2 = Image.open("./Imagenes/mod2.png")
        self.mod2_rs = self.mod2.resize((60,53))
        self.mod2_imag = ImageTk.PhotoImage(self.mod2_rs)

        self.modulo2 = tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo2.place(x=0,y=0)

        self.mod3 = Image.open("./Imagenes/mod3.png")
        self.mod3_rs = self.mod3.resize((60,53))
        self.mod3_imag = ImageTk.PhotoImage(self.mod3_rs)

        self.modulo3 = tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo3.place(x=0,y=0)

        self.mod4 = Image.open("./Imagenes/mod4.png")
        self.mod4_rs = self.mod4.resize((60,53))
        self.mod4_imag = ImageTk.PhotoImage(self.mod4_rs)

        self.modulo4= tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo4.place(x=0,y=0)

        self.mod5 = Image.open("./Imagenes/mod5.png")
        self.mod5_rs = self.mod5.resize((60,53))
        self.mod5_imag = ImageTk.PhotoImage(self.mod5_rs)

        self.modulo5= tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo5.place(x=0,y=0)

        self.mod6 = Image.open("./Imagenes/mod6.png")
        self.mod6_rs = self.mod6.resize((60,53))
        self.mod6_imag = ImageTk.PhotoImage(self.mod6_rs)

        self.modulo6= tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo6.place(x=0,y=0)

        # ----------------------------------------------------------------------
        # ---------------------------- GUI Settings ----------------------------

        ## ----------------------------- Botones -------------------------------
        self.buttonEncender1 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=lambda:[self.encender()])
        self.buttonEncender1.place(
        relx=0.1,
        rely=0.42,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar1 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=lambda:[self.apagar()])
        self.buttonApagar1.place(
        relx=0.27,
        rely=0.42,
        width=130.0,
        height=30.0
        )

        self.buttonEncender2 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=lambda:[self.encenderB()])
        self.buttonEncender2.place(
        relx=0.558,
        rely=0.42,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar2 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarB)
        self.buttonApagar2.place(
        relx=0.725,
        rely=0.42,
        width=130.0,
        height=30.0
        )

        self.buttonEncender3 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderC)
        self.buttonEncender3.place(
        relx=0.1,
        rely=0.62,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar3 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarC)
        self.buttonApagar3.place(
        relx=0.27,
        rely=0.62,
        width=130.0,
        height=30.0
        )

        self.buttonEncender4 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderD)
        self.buttonEncender4.place(
        relx=0.558,
        rely=0.62,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar4 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarD)
        self.buttonApagar4.place(
        relx=0.725,
        rely=0.62,
        width=130.0,
        height=30.0
        )

        self.buttonEncender5 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderE)
        self.buttonEncender5.place(
        relx=0.1,
        rely=0.82,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar5 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarE)
        self.buttonApagar5.place(
        relx=0.27,
        rely=0.82,
        width=130.0,
        height=30.0
        )

        self.buttonEncender6 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderF)
        self.buttonEncender6.place(
        relx=0.558,
        rely=0.82,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar6 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarF)
        self.buttonApagar6.place(
        relx=0.725,
        rely=0.82,
        width=130.0,
        height=30.0
        )
        # ---------------------------- Sliders -----------------------------
        #slider led 1
        self.slider1 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=260,background="#C3CEDA", command = self.intensidadA)
        self.slider1.place(relx=0.1 , rely=0.48)

        # slider led 2
        self.slider2 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=260,background="#C3CEDA", command = self.intensidadB)
        self.slider2.place(x=445 , rely=0.48)

        # slider led 3
        self.slider3 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=260,background="#C3CEDA", command = self.intensidadC)
        self.slider3.place(x=80 , rely=0.68)

        # slider led 4
        self.slider4 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=260,background="#C3CEDA", command = self.intensidadD)
        self.slider4.place(x=445 , rely=0.68)

        # slider led 5
        self.slider5 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=260,background="#C3CEDA", command = self.intensidadE)
        self.slider5.place(x=80 , rely=0.88)

        # slider led 6
        self.slider6 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=260,background="#C3CEDA", command = self.intensidadF)
        self.slider6.place(x=445 , rely=0.88)

        # ------------ Verificación de encendido con variables compartidas --------
        if Formularios.variables_compartidas.modulos["state_mod1"] == False:
            self.apagar()
        else:
            self.encender()
        if Formularios.variables_compartidas.modulos["state_mod2"] == False:
            self.apagarB()
        else:
            self.encenderB()
        if Formularios.variables_compartidas.modulos["state_mod3"] == False:
            self.apagarC()
        else:
            self.encenderC()
        if Formularios.variables_compartidas.modulos["state_mod4"] == False:
            self.apagarD()
        else:
            self.encenderD()
        if Formularios.variables_compartidas.modulos["state_mod5"] == False:
            self.apagarE()
        else:
            self.encenderE()
        if Formularios.variables_compartidas.modulos["state_mod6"] == False:
            self.apagarF()
        else:
            self.encenderF()
        
        # self.slider1.bind("<B1-Motion>", ) #llama a la funcion actualizar valor mientras se mueve
        # self.slider1.bind("<ButtonRelease-1>", self.actualizar_valor_final) #llama a la funcion cuando se deja de mover
        self.slider1.bind("<ButtonRelease-1>", lambda event: self.actualizar_valor_final())
        self.slider2.bind("<ButtonRelease-1>", lambda event2: self.actualizar_valor_final2())
    # ---------------------- Funciones para los sliders ----------------------
    def intensidadA(self, event):
        event = self.slider1.get()
        
        event = self.update_value(event)
        
        event= str(event) + '\n'
        
        # event1= dtype(event)
        # print(event1)
        Formularios.variables_compartidas.sliders["slider1_val"] = event
        
        self.guardar_estado()
        self.ser.write(event.encode())

    def intensidadB(self, event):
        event=self.slider2.get()

        event = self.update_value(event)

        event= str(event) + '\n'

        Formularios.variables_compartidas.sliders["slider2_val"] = (event)
        
        self.guardar_estado()
        self.ser.write(event.encode())

    def intensidadC(self, event):
        event=self.slider3.get()
        event= str(event) + '\n'
        Formularios.variables_compartidas.sliders["slider3_val"] = (event)
        # self.ledC.value=event*0.01
        self.guardar_estado()
    
    def intensidadD(self, event):
        event=self.slider4.get()
        event= str(event) + '\n'
        Formularios.variables_compartidas.sliders["slider4_val"] = (event)
        # self.ledD.value=event*0.01  
        self.guardar_estado()  

    def intensidadE(self, event):
        event=self.slider5.get()
        event= str(event) + '\n'
        Formularios.variables_compartidas.sliders["slider5_val"] = (event)
        # self.ledE.value=event*0.01
        self.guardar_estado()

    def intensidadF(self, event):
        event=self.slider6.get()
        event= str(event) + '\n'
        Formularios.variables_compartidas.sliders["slider6_val"] = (event)
        # self.ledF.value=event*0.01
        self.guardar_estado()

    # ---------------------- Funciones de apagado y encendido ----------------------
    def apagar(self):
        self.buttonEncender1["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar1["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider1.set(0)
        self.intensidadA(0)
        self.slider1["state"]=tk.DISABLED #desabilita slider
        self.modulo1.config(image=self.imagen_transparente_tk)
        self.modulo1.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod1"] = False
        Formularios.variables_compartidas.verificador["1"] = 0

        
        self.guardar_estado()
        # ser.write(event.encode())

    def apagarB(self):
        self.buttonEncender2["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar2["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider2.set(0)
        self.intensidadB(0)
        self.slider2["state"]=tk.DISABLED #desabilita slider
        self.modulo2.config(image=self.imagen_transparente_tk)
        self.modulo2.place(x=0,y=0)

        Formularios.variables_compartidas.modulos["state_mod2"] = False
        Formularios.variables_compartidas.verificador["2"] = 0
        self.guardar_estado()
        # ser.write(event.encode())

    def apagarC(self):
        self.buttonEncender3["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar3["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider3.set(0)
        self.intensidadC
        self.slider3["state"]=tk.DISABLED #desabilita slider
        self.modulo3.config(image=self.imagen_transparente_tk)
        self.modulo3.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod3"] = False
        Formularios.variables_compartidas.verificador["3"] = 0
        self.guardar_estado()
        # ser.write(event.encode())

    
    def apagarD(self):
        self.buttonEncender4["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar4["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider4.set(0)
        self.intensidadD(0)
        self.slider4["state"]=tk.DISABLED #desabilita slider
        self.modulo4.config(image=self.imagen_transparente_tk)
        self.modulo4.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod4"] = False
        Formularios.variables_compartidas.verificador["4"] = 0
        self.guardar_estado()
        # ser.write(event.encode())
    
    def apagarE(self):
        self.buttonEncender5["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar5["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider5.set(0)
        self.intensidadE(0)
        self.slider5["state"]=tk.DISABLED #desabilita slider
        self.modulo5.config(image=self.imagen_transparente_tk)
        self.modulo5.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod5"] = False
        Formularios.variables_compartidas.verificador["5"] = 0
        self.guardar_estado()
        # ser.write(event.encode())

    def apagarF(self):
        self.buttonEncender6["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar6["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider6.set(0)
        self.intensidadF(0)
        self.slider6["state"]=tk.DISABLED #desabilita slider
        self.modulo6.config(image=self.imagen_transparente_tk)
        self.modulo6.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod6"] = False
        Formularios.variables_compartidas.verificador["6"] = 0
        self.guardar_estado()
        # ser.write(event.encode())

    def encender(self): 
        self.buttonApagar1["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender1["state"]=tk.DISABLED #desabilita boton apagar
        self.slider1["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["1"] == 0:
            self.slider1.set(100)
            self.intensidadA(100)
            Formularios.variables_compartidas.verificador["1"] = 1
        elif Formularios.variables_compartidas.verificador["1"] == 1:
            self.slider1.set(Formularios.variables_compartidas.sliders["slider1_val"])
            self.intensidadA(Formularios.variables_compartidas.sliders["slider1_val"])
        self.modulo1.config(image=self.mod1_imag)
        self.modulo1.place(relx=0.14,y=149)
        event= str(self.slider1.get()) + '\n'

        Formularios.variables_compartidas.modulos["state_mod1"] = True
        self.guardar_estado()
        self.ser.write(event.encode())

    def encenderB(self): 
        self.buttonApagar2["state"]=tk.NORMAL #shabiliad boton apagar
        self.buttonEncender2["state"]=tk.DISABLED #desabilita boton apagar
        self.slider2["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["2"] == 0:
            self.slider2.set(100)
            self.intensidadB(100)
            Formularios.variables_compartidas.verificador["2"] = 1
        elif Formularios.variables_compartidas.verificador["2"] == 1:
            self.slider2.set(Formularios.variables_compartidas.sliders["slider2_val"])
            self.intensidadB(Formularios.variables_compartidas.sliders["slider2_val"])
        self.modulo2.config(image=self.mod2_imag)
        self.modulo2.place(x=182,y=149)
        event= str(self.slider2.get()) + '\n'

        Formularios.variables_compartidas.modulos["state_mod2"] = True
        self.guardar_estado()
        # ser.write(event.encode())

    def encenderC(self): 
        self.buttonApagar3["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender3["state"]=tk.DISABLED #desabilita boton apagar
        self.slider3["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["3"] == 0:
            self.slider3.set(100)
            self.intensidadC(100)
            Formularios.variables_compartidas.verificador["3"] = 1
        elif Formularios.variables_compartidas.verificador["3"] == 1:
            self.slider3.set(Formularios.variables_compartidas.sliders["slider3_val"])
            self.intensidadC(Formularios.variables_compartidas.sliders["slider3_val"])
        self.modulo3.config(image=self.mod3_imag)
        self.modulo3.place(x=252.5,y=149)
        event= str(self.slider2.get()) + '\n'
        
        Formularios.variables_compartidas.modulos["state_mod3"] = True
        self.guardar_estado()
        # ser.write(event.encode())

    def encenderD(self): 
        self.buttonApagar4["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender4["state"]=tk.DISABLED #desabilita boton apagar
        self.slider4["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["4"] == 0:
            self.slider4.set(100)
            self.intensidadD(100)
            Formularios.variables_compartidas.verificador["4"] = 1
        elif Formularios.variables_compartidas.verificador["4"] == 1:
            self.slider4.set(Formularios.variables_compartidas.sliders["slider4_val"])
            self.intensidadD(Formularios.variables_compartidas.sliders["slider4_val"])
        self.modulo4.config(image=self.mod4_imag)
        self.modulo4.place(x=252.5,y=87)
        event= str(self.slider4.get()) + '/n'
        
        Formularios.variables_compartidas.modulos["state_mod4"] = True
        self.guardar_estado()
        # ser.write(event.encode())
    
    def encenderE(self): 
        self.buttonApagar5["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender5["state"]=tk.DISABLED #desabilita boton apagar
        self.slider5["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["5"] == 0:
            self.slider5.set(100)
            self.intensidadE(100)
            Formularios.variables_compartidas.verificador["5"] = 1
        elif Formularios.variables_compartidas.verificador["5"] == 1:
            self.slider5.set(Formularios.variables_compartidas.sliders["slider5_val"])
            self.intensidadE(Formularios.variables_compartidas.sliders["slider5_val"])
        self.modulo5.config(image=self.mod5_imag)
        self.modulo5.place(x=182,y=87)
        event= str(self.slider5.get()) + '/n'
        
        Formularios.variables_compartidas.modulos["state_mod5"] = True
        self.guardar_estado()
        # ser.write(event.encode())

    def encenderF(self): 
        self.buttonApagar6["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender6["state"]=tk.DISABLED #desabilita boton apagar
        self.slider6["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["6"] == 0:
            self.slider6.set(100)
            self.intensidadF(100)
            Formularios.variables_compartidas.verificador["6"] = 1
        elif Formularios.variables_compartidas.verificador["6"] == 1:
            self.slider6.set(Formularios.variables_compartidas.sliders["slider6_val"])
            self.intensidadF(Formularios.variables_compartidas.sliders["slider6_val"])
        self.modulo6.config(image=self.mod6_imag)
        self.modulo6.place(x=112,y=87)
        event= str(self.slider6.get()) + '/n'
        
        Formularios.variables_compartidas.modulos["state_mod6"] = True
        self.guardar_estado()
        # ser.write(event.encode())
     
    # --------- Funciones para guardar y actualizar estado ---------------
    def guardar_estado(self):
        # Variables adicionales que deseas guardar
        variables = {
            "modulos": Formularios.variables_compartidas.modulos,
            "sliders": Formularios.variables_compartidas.sliders,
            "verificador": Formularios.variables_compartidas.verificador
            # Agrega más variables aquí según sea necesario
        }

        # Guardar el estado en el archivo
        with open('./Formularios/variables_compartidas.py', 'w') as file:
            for key, value in variables.items():
                file.write(f"{key} = {value}\n")

    def update_value(self, event):
        # Convertir el valor a un número de punto flotante
        value = event
        # Mapeo inverso del valor del slider
        mapped_value = 150 - (value * 1.49)
        print(mapped_value)
        return mapped_value

    # def actualizar_valor_final(self):
    #     event = self.slider1.get()
    #     event = "$SA"+str(event) + '\n'
    #     # ser.write(event.encode())
    
    # def actualizar_valor_final2(self):
    #     event2 = self.slider2.get()
    #     event2 = "$SB"+str(event2) + '\n'
        # # ser.write(event.encode())
